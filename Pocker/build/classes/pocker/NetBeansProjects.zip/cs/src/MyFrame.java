
import java.awt.*;
import javax.swing.*;

public class MyFrame {

    public MyFrame() {
        JFrame jf = new JFrame("我的窗口");
        jf.setExtendedState(JFrame.MAXIMIZED_BOTH);
        ImageIcon img = new ImageIcon("img/bj.jpg");
        JLabel jl = new JLabel(img);
        Container cp = jf.getContentPane();
        cp.add(jl);
        JLayeredPane jp = jf.getLayeredPane();
        jp.setLayout(null);
        for (int ck = 0; ck < 13; ck++) {
            ImageIcon pk = new ImageIcon("img/fang" + (ck + 1) + ".jpg");
            JButton jb = new JButton(pk);
            jb.setBounds(100 + 50 * ck, 300, 134, 201);
            jp.add(jb, new Integer(ck));
        }
        jf.setVisible(true);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new MyFrame();
    }
}
